#!/bin/sh
swaybg -i /home/znorvik/dotfiles/tyler-lastovich-hM08wZJBlK4-unsplash.jpg
dunst &
nm-applet &
sleep 0.5 && pipewire &
sleep 0.5 && pipewire-pulse &
sleep 0.5 && wireplumber &

sleep 0.5 && env GTK_THEME=BlackAndWhite waybar -c ~/.config/waybar/config-dwl.jsonc -s ~/.config/waybar/style-dwl.css &
